package miniproject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

import javax.swing.text.html.HTMLDocument.Iterator;

public class ReadCsv {

	public LinkedList read()
	{
		String str=" ";
		LinkedList <String[]> row=new LinkedList<>();
		int count=0;
		String arr[]=new String[14];
		
		 try {
				
				File f=new File("D:\\complaints.csv");
				BufferedReader bf=new BufferedReader(new FileReader(f));
				
				try {
					while((str=bf.readLine())!=null)
					{
						try {
							str=bf.readLine();
							row.add(str.split(","));
							count++;
							
							
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			
			return row;
			
		}
	public void Display(LinkedList<String[]> row)
	{
		
		java.util.Iterator<String[]> i=row.iterator();
		
		while(i.hasNext())
		{
			String[] str=(String[]) i.next();
			
			for(int k=0;k<14;k++)
			System.out.println("\t\t "+str[k]);
			
			System.out.println();
		}
			
		 
		 
		 
	
		
		
	}
	}


