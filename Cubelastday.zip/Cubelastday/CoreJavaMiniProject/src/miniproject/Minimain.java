package miniproject;
import java.util.LinkedList;
import java.util.Scanner;


public class Minimain {
	 
		
		public static void main(String[] args) 
		{
			ReadCsv rv=new ReadCsv();
			LinkedList <String[]> row=new LinkedList<>();
			row=rv.read();
			rv.Display(row);
			
			
			System.out.println("Enter Year of complaint:");
			Scanner sc=new Scanner(System.in);
			String year=sc.next();
			
			
			Story story_one=new Story(row);
			story_one.year_issue(year);
			
			System.out.println("Enter Bank name:");
			Scanner sc1=new Scanner(System.in);
			String bank_name1 =sc.next();
			
			Story2 story_two=new Story2(row);
			story_two. bname_issue(bank_name1);
			
			
			
			
		}

	}



