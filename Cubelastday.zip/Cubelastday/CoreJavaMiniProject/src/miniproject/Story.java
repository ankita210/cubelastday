package miniproject;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.LinkedList;

public class Story{

		LinkedList<String[]> li;
		int index=1;
		String date_string[];
		
		
		public Story(LinkedList<String[]> li)
		{
			this.li=li;
		}
		

		public LinkedList year_issue(String year)
		{
			date_string=(String[]) li.get(index);
				
				Iterator i=li.iterator();
			
			while(i.hasNext())
			{
				String[] st=(String[]) i.next();
				
				String [] dateParts = st[0].split("(/)|(-)");
				String day = dateParts[0];
				String month = dateParts[1];
				String year1 = dateParts[2];

				
				if(year1.equals(year))
						{
					for(int k=0;k<14;k++)
						System.out.print("\t\t "+st[k]);
						
						System.out.println();
					
						}
				
			}
			
			
			return li;
			
		}

	}


