package miniproject;

import java.util.Iterator;
import java.util.LinkedList;

public class Story2 {
	
	LinkedList<String[]> li;
	int index=6;
	String bank_name[];
	
	
	public Story2(LinkedList<String[]> li)
	{
		this.li=li;
	
	}
	public LinkedList bname_issue(String bank_name1)
	{
		bank_name=(String[]) li.get(index);
			
			Iterator i=li.iterator();
		
		while(i.hasNext())
		{
			String[] st=(String[]) i.next();
			
			/*String [] dateParts = st[0].split("(/)|(-)");
			String day = dateParts[0];
			String month = dateParts[1];
			String year1 = dateParts[2]; */

			
			if(bank_name.equals(bank_name1))
					{
				for(int k=0;k<14;k++)
					System.out.print("\t\t "+st[k]);
					
					System.out.println();
				
					}
			
		}
	
	return li;
}
}
