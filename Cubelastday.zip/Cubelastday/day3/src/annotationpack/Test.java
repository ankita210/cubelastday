package annotationpack;

import java.util.ArrayList;

public class Test {
    @SuppressWarnings("unchecked")
    public static void main(String args[])
    {
    	@SuppressWarnings("rawtypes")
    	ArrayList alist=new ArrayList();
    	alist.add(12);
    	alist.add(23);
    	System.out.println(alist);
    }

}
