import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;


public class Account {
	
		   private String acno;
			private String name;
			private double  balance;
			public String getAcno() {
				return acno;
			}
			public void setAcno(String acno) {
				this.acno = acno;
			}
			public String getName() {
				return name;
			}
			public void setName(String name) {
				this.name = name;
			}
			public double getBalance() {
				return balance;
			}
			public void setBalance(double  balance) {
				this.balance = balance;
			}
			public Account(String acno, String name, double balance) {
				super();
				this.acno = acno;
				this.name = name;
				this.balance = balance;
				
				
			}
			public static void main(String args[])
			{
				InputStreamReader isr=new InputStreamReader(System.in);
				BufferedReader br=new BufferedReader(isr);
				try{
					System.out.println("Enter Account details:");
					String data=br.readLine();
					String a[]=data.split(",");
					Account account=new Account(a[0],a[1],Double.parseDouble(a[2]));
							/*System.out.println("Name:"+getName().toUpperCase());
							System.out.println("ACno:"+account.getAcno());
							System.out.println("Balance:"+balance.getBalance());
*/
					System.out.printf("Name: %s \n Acc no:%s \n Balance:%.2f",
							account.getName().toUpperCase(),account.getAcno(),account.getBalance());
							
				}catch(IOException e)
				{
					e.printStackTrace();
				}
				catch(Exception e)
				{
					System.out.println("INVALID"+e.getMessage());
				}
				}
			}
	
