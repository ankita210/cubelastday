import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;

import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;


public class TestFile {
	public static void main(String args[]) throws Exception
	{
		
		/*FileInputStream fis=new FileInputStream("D:/test.txt");
		FileOutputStream fos=new FileOutputStream("D:/test_copy.txt");
		int ch;
				while ((ch = fis.read()) != -1)
				{
				   if (Character.isLowerCase(ch))
				   {
				        ch=Character.toUpperCase(ch);
				   }
				fos.write(ch);
				}
				fis.close();
				fos.close(); */
		BufferedReader br=new BufferedReader(new FileReader("d:/test.txt"));
	int line=1;
	while(true)
	{
		String s=br.readLine();
		if(s==null)
			break;
		if(s.indexOf("new")!=-1)
			System.out.println(line+":"+s);
		line++;
	}
	
	
	}
			
}

		/*String a[]=file.list();
		for(String b:a)
		{
			System.out.println(b);
		}
		if(file.isFile()==true)
			System.out.println("it is a file");
		else if(file.isDirectory()==true)
		System.out.println("it is directory");
			else 
			System.out.println("it is a folder");
		System.out.println("size:"+file.length());
	*/
		//file.mkdir();
		//file.delete();
		
	
//BufferedReader in = (new BufferedReader(newFileReader(file1)));
//PrintWriter out = (new PrintWriter(new FileWriter(file2)));