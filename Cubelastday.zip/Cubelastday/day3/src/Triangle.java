import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.*;

public class Triangle {
	public static void main(String args[])
	{
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		

			String data1,data3,data2;
		    
			try {
				System.out.println("Enter side1:");
				 
				 String data11 = br.readLine();
				 double a = Double.parseDouble(data11);
				  
				 
				System.out.println("Enter side2:");
				
				 String data111 = br.readLine();
				 double b = Double.parseDouble(data111);
				System.out.println("Enter side3:");
				String data1111 = br.readLine();  
				double c = Double.parseDouble(data1111);
										
				if((a+b)>c && (a+c)>b && (b+c)>a)
				{
				 double s=(a+b+c/2);
				 double s1=s*(s-a)*(s-b)*(s-c);
				 double area=Math.sqrt(s1);
				 System.out.println("Area is "+area);
				}
				else
					throw new Exception("No area");
						
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("Er1:"+e.getMessage());
			}
			catch (Exception e) {
				System.out.println("Er2:"+e.getMessage());
			}
		
	}

}



