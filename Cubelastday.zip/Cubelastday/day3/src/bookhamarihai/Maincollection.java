package bookhamarihai;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Maincollection {

    public static void main(String args[])
    {
    	String choice=null;
    	Scanner sc=new Scanner(System.in);
    	ArrayList<Book> bookList=new ArrayList<>();
    	do{
    		System.out.println("Enter book information");
    	    String data=sc.nextLine();
    	    String a[]=data.split(",");
    	    Book book = new Book(a[0],a[1],Double.parseDouble(a[2]));
    	    bookList.add(book);
    	        System.out.println("Continue?YES/NO");
    	    choice=sc.nextLine();
    	}while(choice.equalsIgnoreCase("YES"));
    	
    	Collections.sort(bookList,new PriceComparator());
    	
    	
    	
    	
    	for(Book b:bookList)
    	{
    		System.out.println(b.getB_name()+" "+b.getB_author()+" "+b.getPrice());
    	}
    	sc.close();
    	//Book b=bookList.get(0);
    	/*System.out.println(b.getB_name()+" "+b.getB_author()+" "+b.getPrice());
    	Book b1=bookList.get(bookList.size()-1);
    	System.out.println(b1.getB_name()+" "+b1.getB_author()+" "+b1.getPrice());*/
    	
    }

	
		
	}

