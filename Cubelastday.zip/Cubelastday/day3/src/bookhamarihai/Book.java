package bookhamarihai;

public class Book {
	String b_name;
	String b_author;
	double price;
	public Book(String b_name, String b_author, double price) {
		super();
		this.b_name = b_name;
		this.b_author = b_author;
		this.price = price;
	}
	public String getB_name() {
		return b_name;
	}
	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
	public String getB_author() {
		return b_author;
	}
	public void setB_author(String b_author) {
		this.b_author = b_author;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public static void main(String args[])
	{
		
	}

}
