package bookhamarihai;

import java.util.Comparator;

public class PriceComparator implements Comparator<Book>{
	
	

}
