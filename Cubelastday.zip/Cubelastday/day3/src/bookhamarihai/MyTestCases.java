package bookhamarihai;
import org.junit.Test;
import static org.junit.Assert.*;

public class MyTestCases {

	public class yo {
		@Test
		public void test1(){
			calc ca =new calc();
			int res =ca.add(12, 35);
	         assertEquals(35,res);
		}
		

	}

}
