package bookhamarihai;

import java.util.Scanner;

public class calc {

	public int add(int a, int b)
	{
		
		return a+b;
	}
	public boolean check(int n)
	{
		
		Scanner sc=new Scanner(System.in);
		if(n%2==0)
			return true;
		else
			return false;
		
		
	}
}
