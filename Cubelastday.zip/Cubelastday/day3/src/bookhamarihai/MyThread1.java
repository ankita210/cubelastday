package bookhamarihai;

public class MyThread1 implements Runnable {
	Thread t;
	public MyThread1(String a)
	{
		t=new Thread(this,a);
		t.start();
	}
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println(i+" "+t.getName());
			try{
				t.sleep(1000);
			   }
			catch(InterruptedException e)
			{
				
			}
		}
	}
	public static void main(String args[])
	{
		MyThread th1=new MyThread("AAAA");
		MyThread th2=new MyThread("BBBB");
	
	}
	
}
