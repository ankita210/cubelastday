package bookhamarihai;

import java.security.KeyStore.Entry;
import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;

public class MainCollection3 {
	 public static void main(String args[])
	    {
	    	String choice=null;
	    	Scanner sc=new Scanner(System.in);
	    	TreeMap<Integer,Book> bookList=new TreeMap<>();
	    	do{
	    		System.out.println("Enter book information[id,name,author,price]");
	    	    String data=sc.nextLine();
	    	    String a[]=data.split(",");
	    	    Book book= new Book(a[1],a[2],Double.parseDouble(a[3]));
	    	    bookList.put(Integer.parseInt(a[0]),book);
	    	        System.out.println("Continue?YES/NO");
	    	    choice=sc.nextLine();
	    	}while(choice.equalsIgnoreCase("YES"));
	    	for(java.util.Map.Entry<Integer, Book> entry:bookList.entrySet()) 
	    	{
	    		int key=entry.getKey();
	    		Book  b= entry.getValue();
	    		System.out.println(key+" "+b.getB_name()+" "+b.getB_author()+" "+b.getPrice());
	    	}
	    	
	    }

		
			


}
