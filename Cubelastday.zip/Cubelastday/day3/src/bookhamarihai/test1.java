package bookhamarihai;

import java.util.HashMap;
import java.util.TreeMap;

public class test1 {
	public static void main(String args[])
	{
		HashMap<Integer, String> hmap=new HashMap<>();
		hmap.put(189, "India");
		hmap.put(89, "Nepal");
		hmap.put(289, "Bhutan");
		System.out.println(hmap);
		TreeMap<Integer, String> tmap=new TreeMap<>(hmap);
		System.out.println(tmap);
		if(hmap.containsKey(5589))
		{
			String s=hmap.get(5589);
			System.out.println(s);
		}
		else
		{
			System.out.println("Not found key");
		}
		
		
		/*
		for(java.util.Map.Entry<Integer, String>  entry:tmap.entrySet()) 
    	{
    		int key=entry.getKey();
    		String value= entry.getValue();
    		System.out.println(key+" "+value);
    
		
	}*/

	}
}
