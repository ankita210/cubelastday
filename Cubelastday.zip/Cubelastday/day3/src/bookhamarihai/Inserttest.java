package bookhamarihai;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Inserttest {
	public static void main(String args[]) 
	{
		Connection connection=null;
		try {
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Book_id");
			int id=Integer.parseInt(sc.nextLine());
			System.out.println("Enter book_name");
			String name=sc.nextLine();
			System.out.println("Enter author");
		 String author=sc.nextLine();
		 System.out.println("Enter price");
		 int price=Integer.parseInt(sc.nextLine());
		 
		Class.forName("oracle.jdbc.driver.OracleDriver");
		connection =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
				"hr","hr");
		//Statement smt =connection.createStatement();
		//smt.executeUpdate("insert into student values(101,'ram',234)");
		//smt.executeUpdate("insert into student values(101,'meranam',301)");
		PreparedStatement pst=connection.prepareStatement("insert into Book values(?,?,?,?)");
		pst.setInt(1, id);
		pst.setString(2, name);
		pst.setString(3, author);
		pst.setInt(4, price);
		pst.executeUpdate();
		System.out.println("Record is added");
	}
	
catch(ClassNotFoundException e)
{
	System.out.println(e);
	}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		finally{
			try{
				connection.close();				
			}
			catch(Exception e)
			{
				System.out.println(e);
				
			}
			
		}
}
}