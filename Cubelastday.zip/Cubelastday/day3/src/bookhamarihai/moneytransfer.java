package bookhamarihai;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Scanner;

public class moneytransfer {

	public static void main(String args[]) 
	{
		Connection connection=null;
		try {
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter ");
			int acno=Integer.parseInt(sc.nextLine());
			
			System.out.println("Enter a_name");
			String aname=sc.nextLine();
			
			System.out.println("Enter balance");
			int balance=Integer.parseInt(sc.nextLine());
			
			
			System.out.println("Enter the amount");
			int amount=Integer.parseInt(sc.nextLine());
			
System.out.println("Enter the amount to be credit");
int amount1=Integer.parseInt(sc.nextLine());

			
		Class.forName("oracle.jdbc.driver.OracleDriver");
		connection =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
				"hr","hr");
		
		if(a==1 && b==1)
			con.commit();
		else
			con.rollback();
		
con.close();
		}
		
		
}
