package bookhamarihai;

 class Printer {

	public synchronized void print(String name)
	{
		System.out.println("[" +name + "start point");
		try{
			Thread.sleep(5000);
			
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		System.out.println("]");
	}
	
}
class User extends Thread
{
	String uname;Printer p;


	public User(String uname, Printer p) 
	{
		super();
		this.uname = uname;
		this.p = p;
	}
	public void run()
	{
		p.print(uname);
	}
	


	
	public static void main(String args[])
	{
		Printer pr = new Printer();
		User u1= new User("JACK",pr);
		User u2= new User("I_IS_THE_HUMAN",pr);
		u1.start();u2.start();
	}
	
}

