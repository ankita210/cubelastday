package bookhamarihai;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class MainCollection2 {
	  public static void main(String args[])
	    {
	    	String choice=null;
	    	Scanner sc=new Scanner(System.in);
	    	HashMap<Integer,Book> bookList=new HashMap<>();
	    	do{
	    		System.out.println("Enter book information[id,name,author,price]");
	    	    String data=sc.nextLine();
	    	    String a[]=data.split(",");
	    	    Book book= new Book(a[1],a[2],Double.parseDouble(a[3]));
	    	    bookList.put(Integer.parseInt(a[0]),book);
	    	        System.out.println("Continue?YES/NO");
	    	    choice=sc.nextLine();
	    	}while(choice.equalsIgnoreCase("YES"));
	    	System.out.println("Enter book Id:");
	    	Integer id=Integer.parseInt(sc.nextLine());
	    	Book b=bookList.get(id);
	    	if(b!=null)
	    	System.out.println(b.getB_name()+" "+b.getB_author()+" "+b.getPrice());
	    	else
	    		System.out.println("object not found");
	    	sc.close();
	    	
	    }

		
			

}
