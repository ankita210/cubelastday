package bookhamarihai;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class accountp {
	
		public static void main(String args[]) 
		{
			Connection connection=null;
			try {
				
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter account_id");
				int acno=Integer.parseInt(sc.nextLine());
				
				System.out.println("Enter a_name");
				String aname=sc.nextLine();
				
				System.out.println("Enter balance");
				int balance=Integer.parseInt(sc.nextLine());
				
				
				System.out.println("Enter the amount");
				int amount=Integer.parseInt(sc.nextLine());
				
	System.out.println("Enter the amount to be credit");
	int amount1=Integer.parseInt(sc.nextLine());
	
				
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
					"hr","hr");
			//Statement smt =connection.createStatement();
			//smt.executeUpdate("insert into student values(101,'ram',234)");
			//smt.executeUpdate("insert into student values(101,'meranam',301)");
			if(balance>amount)
			{
			int z=(balance-amount);
			System.out.println(z);
			}
			else
			{
				System.out.println("cannot debit");
			}
			
			
			
			PreparedStatement pst=connection.prepareStatement("insert into accounts values(?,?,?)");
			pst.setInt(1, acno);
			pst.setString(2, aname);
			pst.setInt(3, balance);
			pst.executeUpdate();
			System.out.println("Record is added");
			
			ResultSet rs=pst.executeQuery();
			if(rs.next()){
				int tot=rs.getInt(3);
				System.out.println("Name: "+rs.getString(2));
				System.out.println("Balance "+tot);
				
				PreparedStatement pst1=connection.prepareStatement("Update table SET balance =z WHERE acno=acno");
				pst1.setInt(1, acno);
				
				
				
				
				//System.out.println(tot"Pass":"Fail");
		}
			}
		
	catch(ClassNotFoundException e)
	{
		System.out.println(e);
		}
			catch(SQLException e)
			{
				System.out.println(e);
			}
			finally{
				try{
					connection.close();				
				}
				catch(Exception e)
				{
					System.out.println(e);
					
				}
				
			}
	}
	}


