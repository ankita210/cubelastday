package bookhamarihai;
import java.util.HashSet;
import java.util.Scanner;
public class Collection2 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=0;
		HashSet<Integer> numbers=new HashSet<>();
		while(true)
		{
			System.out.println("Enter number(0 to exit)");
			n=Integer.parseInt(sc.nextLine());
			if(n==0)
				break;
			numbers.add(n);
		}
			int sum=0;
		for(Integer i:numbers)
		{
			System.out.println(i);
			sum+=i;
		}
		System.out.println("Sum:"+sum);
		System.out.printf("\n%.2f",(double)sum/numbers.size());
		sc.close();
	}

}
