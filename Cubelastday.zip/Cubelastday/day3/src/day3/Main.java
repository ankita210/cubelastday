package day3;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class Main {
	public static void main(String args[])
	{
		Emp e=new Emp();
		
		Class c = e.getClass();
		System.out.println(c);
		
		Constructor cc[]=c.getConstructors();
		for(Constructor x:cc)
		{
			System.out.println(x);
		}
		Method methods[]=c.getMethods();
		for(Method m:methods)
		{
			System.out.println(m);
		}
	}

}
