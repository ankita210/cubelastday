package day3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class circle {
	public static void main(String args[])
	{
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		

			String data;
			try {
				System.out.println("Enter radius:");
				data = br.readLine();
				double radius = Double.parseDouble(data);
				double area=Math.PI * radius*radius;
				System.out.println("Area is "+area);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("Er1:"+e.getMessage());
			}
			catch (Exception e) {
				System.out.println("Er2:"+e.getMessage());
			}
		
	}

}
