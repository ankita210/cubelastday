package day3;

public class Emp {
	private String  name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Emp(String name) {
		super();
		this.name = name;
	}
	public Emp(){}

}
