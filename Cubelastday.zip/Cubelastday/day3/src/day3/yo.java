package day3;

import org.junit.Test;
import static org.junit.Assert.*;
import bookhamarihai.calc;

public class yo {
	@Test
	public void test1(){
		calc ca =new calc();
		//int res =ca.add(12, 35);
         //assertEquals(30,res);
		boolean res=ca.check(15);
		assertTrue(res);
	}
	

}
