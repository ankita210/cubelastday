
public class employee {
	private String name;
	private int age;
	public employee(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	public static void main(String args[])
	{
		Employee emp1= new Employee("YOYOYOYO",90);
		
		
		ObjectInputStream ois= new ObjectInputStream(new FileInputStream("d:/obj.bin"));
		employee e1=(employee)ois.readObject();
		System.out.println(e1.name+ ""  +);
		
	}

}
