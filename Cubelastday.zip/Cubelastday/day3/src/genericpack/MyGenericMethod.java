package genericpack;

public class MyGenericMethod {

	public <T> void show (T a[])
	{
		System.out.println("List:");
		for(T x:a)
			System.out.println(x+" ");
	}
	public static void main(String args[])
	{
		int x[]={12,23,34,45};
		new MyGenericMethod().show(x);
		String y[]={"India","Bhutan"};
		new MyGenericMethod().show(y);
	}
}
