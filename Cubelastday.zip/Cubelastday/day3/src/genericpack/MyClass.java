package genericpack;

class MyClass<T>{
	private T data;

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}
	
	public class MyGenericClass
	{
		public static void main(String args[])
		MyClass<String> obj1=new MyClass<String>();
		obj1.setData("LTI");
		System.out.println(obj1.getData());
		
		MyClass<Integer> obj2=new MyClass<Integer>();
		obj2.
	}

}
