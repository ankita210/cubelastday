package pikapi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class test2 {
	
		public static void main(String args[]) 
		{
			Connection connection=null;
			try {
				
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter Department_id");
				int id=Integer.parseInt(sc.nextLine());
				//System.out.println("Enter student_name");
				//String name=sc.nextLine();
				//System.out.println("Enter total_marks");
				//int total=Integer.parseInt(sc.nextLine());
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
					"hr","hr");
			PreparedStatement pst=connection.prepareStatement("select sum(salary),count(employee_id) from emp where department_id=? GROUP BY department_id");
			pst.setInt(1, id);
			//pst.setString(2, name);
			//pst.setInt(3, total);
			ResultSet rs=pst.executeQuery();
			if(rs.next()){
				//int tot=rs.getInt(3);
				//System.out.println("Name: "+rs.getString(2));
				//System.out.println("Total: "+tot);
				//System.out.println(tot>=200?"Pass":"Fail");
				System.out.println("found");
			}
			else
				System.out.println("Record not found");
			//System.out.println("Record is added");
		}
		
	catch(ClassNotFoundException e)
	{
		System.out.println(e);
		}
			catch(SQLException e)
			{
				System.out.println(e);
			}
			finally{
				try{
					connection.close();				
				}
				catch(Exception e)
				{
					System.out.println(e);
					
				}
				
			}
			

		}
	}



