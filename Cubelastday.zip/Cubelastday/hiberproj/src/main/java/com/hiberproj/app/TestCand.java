package com.hiberproj.app;

import com.hiberproj.model.Candidate;
import com.hiberproj.service.CandidateDao;

public class TestCand {

	public static void main(String[] args) {
	
		Candidate candidate=new Candidate();
		candidate.setCid(100);
		candidate.setCname("shailja");
		candidate.setDob(new java.util.Date());
		System.out.println(new CandidateDao().addCan(candidate));

	}

}
