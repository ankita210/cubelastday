package com.hiberproj.service;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hiberproj.model.Candidate;

import com.hiberproj.model.SessionDao;

public class CandidateDao {
	public boolean addCan(Candidate candidate){
		boolean flag=false;
		try{
			Session session=new SessionDao().getSession();
			
			Transaction t = (Transaction) session.beginTransaction();
			session.save(candidate);
			t.commit();
			session.close();
			flag=true;
		}
		catch(Exception ee){
			System.out.println(ee);
		}
		return flag;
	}

	
	}


