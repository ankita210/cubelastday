package com.hiberproj.app;

import com.hiberproj.model.Employee;
import com.hiberproj.service.ServiceDao;

public class TestApplication {
	

	public static void main(String[] args) {
		
		Employee employee = new Employee();
		employee.setEno(100);
		employee.setEname("ANKITaaA");
		employee.setEsal(1000000);
		System.out.println(new ServiceDao().addEmp(employee));
		System.out.println(new ServiceDao().editEmp(employee));
		System.out.println(employee.getEname());
		
		
		
		Employee employee1= new Employee();
		employee1.setEno(100);
		Employee e= new ServiceDao().getEmp(employee1);
		if(e!=null)
			System.out.println(e.getEname());
		else
			System.out.println("not found");
			
	}
	}


