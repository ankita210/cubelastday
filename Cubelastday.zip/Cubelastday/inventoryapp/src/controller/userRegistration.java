package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Users;
import service.UsersDao;

/**
 * Servlet implementation class userRegistration
 */
public class userRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public userRegistration() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userid=request.getParameter("userid");
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String contactno=request.getParameter("contactno");
		String emailid=request.getParameter("emailid");
		String gender=request.getParameter("gender");
		
		Users users = new Users(userid, name, password, emailid, contactno, gender);
		boolean flag = new UsersDao().registerUser(users);
		if(flag) {
			response.sendRedirect("Login.html");
		}
		else {
			response.sendRedirect("REGISTRATION.html");
		}
	}
	

}
