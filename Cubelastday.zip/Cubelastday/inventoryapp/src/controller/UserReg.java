package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.User;
import model.Users;
import service.ProductsDao;
import service.UsersDao;


/**
 * Servlet implementation class ProductRegister
 */
public class UserReg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public UserReg() throws ServletException, IOException {
        super();
        // TODO Auto-generated constructor stub
    }

	
	// ProductRegister(String pid, String pname, String unitprice, String stock, String category) {
		// TODO Auto-generated constructor stub
	


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uid=request.getParameter("uid");
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String Contactno=request.getParameter("Contactno");
		String category=request.getParameter("category");
		
		Users users = new Users( uid , fname,lname, Contactno , category, category);
		boolean flag = new UsersDao().registerUser(users);
		if(flag) {
			RequestDispatcher rd= request.getRequestDispatcher("UserHome.jsp");
			request.setAttribute("msg","USer is successfully added");
			rd.forward(request, response);
		}
		else {
			RequestDispatcher rd= request.getRequestDispatcher("UserHome.jsp");
			request.setAttribute("msg","Sorry!USER is not added");
			rd.forward(request, response);
		}
		
	}

}
