package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.Product;

public class ProductsDao {
	
	public List<Product> getAllProduct(){
		List<Product> plist=new ArrayList<Product>();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver"); // step-1
			Connection con= DriverManager.getConnection(
						"jdbc:oracle:thin:@localhost:1521:xe",
						"hr",
						"hr");
			String sql="select * from product";
			PreparedStatement smt=con.prepareStatement(sql);
			ResultSet rs=smt.executeQuery();
			while(rs.next())
			{
				Product p=new Product(rs.getString(1),rs.getString(2),rs.getInt(3),
						rs.getInt(4),rs.getString(5));
				plist.add(p);
			}
			con.close();
			}
		
		catch(Exception s) { System.out.println(s);}
		return plist;
	
	}
	
	public  boolean registerProduct(Product products){
		boolean result=false;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver"); // step-1
			Connection con= DriverManager.getConnection(
						"jdbc:oracle:thin:@localhost:1521:xe",
						"hr",
						"hr"); // step-2
			PreparedStatement smt =  con.prepareStatement("insert into product values(?,?,?,?,?)");
			smt.setString(1, products.getPid());
			smt.setString(2, products.getPname());
			smt.setInt(3, products.getUnitprice());
			smt.setInt(4, products.getStock());
			smt.setString(5, products.getCategory());
			int res =smt.executeUpdate();
		
			  if(res>0)
			   {
				 result=true;
	    		}
		
				con.close();	
	}
	       	catch (Exception e) { System.out.println(e);}
	        return result;
	}

	}
		


