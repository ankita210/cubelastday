package model;

import java.util.List;

public class User {
	private String uid;
	private String fname;
	private String lname;
	private String contactno;
	private String category;
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getContactno() {
		return contactno;
	}
	public void setContactno(String contactno) {
		this.contactno = contactno;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public User(String uid, String fname, String lname, String contactno, String category) {
		super();
		this.uid = uid;
		this.fname = fname;
		this.lname = lname;
		this.contactno = contactno;
		this.category = category;
	}
	public User() {
		super();
	}
	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
	