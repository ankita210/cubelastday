package model;

public class Users {
	private String userid;
	private String name;
	private String password;
	private String emailid;
	private String contactno;
	private String gender;
	public Users() {
		super();
	}
	public Users(String userid, String name, String password, String gender, String emailid, String contactno) {
		super();
		this.userid = userid;
		this.name = name;
		this.password = password;
		this.emailid = emailid;
		this.contactno = contactno;
		this.gender = gender;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getContactno() {
		return contactno;
	}
	public void setContactno(String contactno) {
		this.contactno = contactno;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}

}
