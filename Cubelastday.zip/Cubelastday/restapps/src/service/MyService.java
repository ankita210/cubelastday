package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.Track;


public class MyService {
	
	public boolean addTrack(Track track) {
		boolean result = false;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe",
					"hr",
					"hr"); 
			//PreparedStatement smt = con.prepareStatement("insert into track values(?,?)");
			PreparedStatement smt = con.prepareStatement("delete from track where title=?)");
		  smt.setString(1,  track.getTitle());
		  smt.setString(2,  track.getSinger());
		 
		  int rs=smt.executeUpdate();
		  con.close();
		  if(rs>0) 
			  result=true;
		}
		catch(Exception e){ 
			System.out.println(e);
		}
		return result;
		
		
	}
	public List<Track> getAllTracks(){
		List<Track> tlist=new ArrayList<Track>();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver"); // step-1
			Connection con= DriverManager.getConnection(
						"jdbc:oracle:thin:@localhost:1521:xe",
						"hr",
						"hr");
			String sql="select * from Track";
			PreparedStatement smt=con.prepareStatement(sql);
			ResultSet rs=smt.executeQuery();
			while(rs.next())
			{
				Track p=new Track(rs.getString(1),rs.getString(2));
				tlist.add(p);
			}
			con.close();
			}
		
		catch(Exception s) { System.out.println(s);}
		return tlist;
	
	}
	public Track getTrack(String title){
		Track track=null;
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver"); // step-1
			Connection con= DriverManager.getConnection(
						"jdbc:oracle:thin:@localhost:1521:xe",
						"hr",
						"hr");
			String sql="select * from Track where title=?";
			PreparedStatement smt=con.prepareStatement(sql);
			smt.setString(1, title);
			ResultSet rs=smt.executeQuery();
			if(rs.next()){
				track =new Track(rs.getString(1),rs.getString(2));
			
			}
			con.close();
			}
		
		catch(Exception s) { System.out.println(s);}
		return track;
	
	}
	public boolean deleteTrack(String title) {
		boolean result = false;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe",
					"hr",
					"hr"); 
			
			PreparedStatement smt = con.prepareStatement("delete from track where title=?)");
		  smt.setString(1,  title);
		  
		  int rs=smt.executeUpdate();
		  con.close();
		  if(rs>0) 
			  result=true;
		}
		catch(Exception e){ 
			System.out.println(e);
		}
		return result;
		
		


}
}
