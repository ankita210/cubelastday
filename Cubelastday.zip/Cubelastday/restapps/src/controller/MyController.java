package controller;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import model.RestResponse;
import model.Track;
import service.MyService;
//import model.Track;

@Path("/tracks")
public class MyController {
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	
	
	public List<Track> getAllTracks(){
		 List<Track> tlist =new MyService().getAllTracks();
		return tlist;
	}
	@GET
	@Path("/get/{title}")
	@Produces(MediaType.APPLICATION_JSON)
	
	public Track getTrack(@PathParam("title") String title) {
		Track track=new MyService().getTrack(title);
		return track;
	}
	
	@POST
	@Path("/post")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public RestResponse addTrack(Track track){
		boolean flag = new MyService().addTrack(track);
		RestResponse restResponse = new RestResponse();
		if(flag)
		{
			 restResponse.setCode(200);
			 restResponse.setMessage("yo added");
			 
			 
		}
		else
		{
			restResponse.setCode(-1);
			 restResponse.setMessage("NOt added");
			 
		}
		return restResponse;
		
	}
	@DELETE
	@Path("/delete/{title}")
	@Produces(MediaType.APPLICATION_JSON)
	public RestResponse deleteTrack(@PathParam("title")String title) {
		RestResponse restResponse = new RestResponse();
		boolean flag = new MyService().deleteTrack(title);
		if(flag)
		{
			 restResponse.setCode(200);
			 restResponse.setMessage("yo removed");
			 
			 
		}
		else
		{
			restResponse.setCode(-1);
			 restResponse.setMessage("NOt removed");
			 
		}
		return restResponse;
		
		
	}
}


