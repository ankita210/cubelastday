package inherit3;

public class interface1 {

         public interface Interface1 {
        	 int data=12;
        	 public void show();
        	 }
         
}
