package inherit3;

	public class Myclass implements Interface1, Interface2 {
		
		public void disp(int a)
		{
			System.out.println(a+data);
		}
		public void show()
		{
			System.out.println("My Output");
		}
		public static void main(String args[]) {
			Myclass myclass=new Myclass();
			myclass.show();
			myclass.disp(120);
		}
	}


