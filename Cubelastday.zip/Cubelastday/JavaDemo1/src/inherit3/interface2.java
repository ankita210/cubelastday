package inherit3;

public class interface2 {
	public interface Interface2  {
		public void disp(int a);
	}

}
