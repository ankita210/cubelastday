package inherit2;

public class C extends A {
	public void show()
	{
		System.out.println("I is the mammal");
	}


}
