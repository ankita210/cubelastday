package constructors;


public class Savings extends Account {
	

	   public void withdraw(int amount)
	   {
		   try{
			   if(getBalance()-amount>=1000)
				   setBalance(getBalance()-amount);
			   else
				   throw new Exception("Insufficient balance");
			   
		   }
		   catch(Exception e)
		   {
			   System.out.println(e.getMessage());
		   }
	   }
	  }
	   
		 
