package constructors;

public class Manager extends Emp {
	
	private int salary;
	public Manager()
	{
		super();
		salary=-100;
	}
	
	public Manager(String name, int age,int salary) {
		super(name, age);
		// TODO Auto-generated constructor stub
	}
	public Manager(int salary) {
		super();
		this.salary = salary;
	}
	public void show()
	{
		super.show();
		System.out.println(salary);
	}
	public static void main(String args[])
	{
		Manager m1=new Manager(); m1.show();
		Manager m2=new Manager("Earn",23,23000);  m2.show();
	}

}
