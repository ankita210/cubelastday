package inherit;

public class Main {

	public static void main(String args[])
	{
	A objA=new A();
	objA.show();
	System.out.println("-----------------------");
	
	C objC=new C();
	objC.show();
	}
}


