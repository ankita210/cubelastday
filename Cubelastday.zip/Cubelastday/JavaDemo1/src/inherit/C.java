package inherit;

public class C extends A {
	public void disp()
	{
		System.out.println("I is the mammal");
	}

}
