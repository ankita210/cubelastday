package inherit;

public interface B {

}
