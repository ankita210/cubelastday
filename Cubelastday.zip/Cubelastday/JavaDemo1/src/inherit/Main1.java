package inherit;

public class Main1 {
	public static void main(String args[])
	{
		A objA=new A();
		objA.show();
		//System.out.println("-----------------------");
		
		C objC=new C();
		A objX= objC;
		C objY=(C)objA;
		//objC.show();
		//objC.disp();
		class emp
		{
			String name;
			int age;
			
			public
		}
		
		
		
		
	}

}
