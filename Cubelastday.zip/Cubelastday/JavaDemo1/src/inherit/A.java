package inherit;

public class A {
	
	public void show()
	{
		System.out.println("I is a human");
	}

}
