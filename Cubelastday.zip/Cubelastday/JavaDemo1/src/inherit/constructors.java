package inherit;

public class constructors {

}
