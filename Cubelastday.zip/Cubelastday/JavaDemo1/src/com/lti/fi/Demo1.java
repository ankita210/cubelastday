package com.lti.fi;

 class Demo1 {
	
	private void factorial(int n)
	{
	
	int fact=1;
	for(int i=1;i<=n;i++)
	{
		fact=fact*i;
	}
		System.out.println("Factorial is of"+n+"is:"+fact);
	
}
   public void callingMethod()
   {
	   factorial(5);
   }

}
