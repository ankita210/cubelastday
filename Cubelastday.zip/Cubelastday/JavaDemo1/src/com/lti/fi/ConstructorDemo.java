package com.lti.fi;

public class ConstructorDemo {
	
	int a;
	int b;
	/*public ConstructorDemo()
	{
	   a=10;
	   b=20;
	}
	
	public ConstructorDemo(int x,int y)
	{
		a=x;
		b=y;
	}*/
	
	public void add()
	{
		System.out.println(a+b);
	}

}
