package com.lti.fi;
import java.util.Arrays;
public class DemoReturns {
	public void oddeven(int a)
	{
		if(a%2==0)
		{
			System.out.println("No is even");
		}
		else
		{
			System.out.println("No is odd");
		}
	}
	
	  public void ArrayDemo()
	  {
		  int arr1[]={10,45,23,78,8};
		  System.out.println(arr1.length);
		 
	  
	 for(int i=arr1.length;i>=0;i--)
	  {
		 
		 System.out.println(arr1[i]);
		  
		  
		  
	 }
	   Arrays.sort(arr1);
	  for(int x:arr1)
	  {
		  
		  System.out.println(x);
		  
	  }
	  
	  
		  
		  
	  }
}
