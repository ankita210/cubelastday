package com.lti.fi;

public class IfDemo {
	public static void main(String args[])
	{
		int a =100;
		int b=200;
		int c=30;
		
		if(a>b)
		{
			if(a>c)
			System.out.println(a+"is greater");
		}
		else if(b>c)
		{
			System.out.println(b+"is greater");
		}
		else
		{
			System.out.println(c+"is greater");
		}
		
		int z=Math.max(a,b);
		System.out.println("Max is :"+z);
		
		int t=Math.min(a,b);
		System.out.println("Min is :"+t);
		
		System.out.println(Math.max(c, Math.max(a, b)));
		
		System.out.println(Math.min(c, Math.min(a, b)));
		
		
	}

}
