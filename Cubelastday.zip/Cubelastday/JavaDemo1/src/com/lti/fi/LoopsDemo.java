package com.lti.fi;

public class LoopsDemo {
	public static void main(String args[])
	{
	   //*int a=999;
		//int i=1;
		//int table=0;
		/*while(i<=10)
		{
			table=a*i;
			System.out.println(a+"*"+i+"="+table);
			i++;
		}*/
		
		/*for(int i=1;i<=10;i++)
		{
			table=a*i;
			System.out.println(a+"*"+i+"="+table);
		}*/
		
		/*do{
			table=a*i;
		System.out.println(a+"*"+i+"="+table);
		i++;
		}while(i<=10);*/
		int sum=0;
		/*for(int i=0;i<=20;i++)
		{
			
			if(i%2==0)
			{
			sum=sum+i;
			}
		}
			System.out.println(sum);*/
			
		
		/*int i=1;
		
		while(i<=20)
		{
			
				sum=sum+i;
			 i+=2;
			
		}
		System.out.println("Addition of first 10 even numbers="+sum);*/
		
		
		int n=0;
		int fact=1;
		for(int i=1;i<=n;i++)
		{
			fact=fact*i;
		}
			System.out.println("Factorial is of"+n+"is:"+fact);
		
	}
				
}
	
	


