package com.lti.fi;
import java.util.Scanner;
public class ExceptionDemo {
	public void divide()
	{
		try{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=10;
		
			int c=b/a;
			System.out.println(c);
		}catch(ArithmeticException ae)
		{
			System.out.println(ae.getMessage());
		}
		catch(Exception e)
		{
		//System.out.println(e);
		//throw new ArithmeticException("Not valid");
		System.out.println("Base Class Exception"+e.getMessage());
		}
		
		
	}

}
