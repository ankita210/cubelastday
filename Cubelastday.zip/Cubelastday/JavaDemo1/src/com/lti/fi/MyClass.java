package com.lti.fi;

public class MyClass {
	public static void main(String args[])
	{
		/*int a=10;
		int b=20;
				
		float e=10.7f;
		float f=20f;
		
		double x=15.89f;
		double y=20.9f;
		 
		char l='x';
		
		String str="Ankita";
		System.out.println("The addition is:"+(a+b));
		System.out.println("The addition is:"+(e+f));
		System.out.println("The addition is:"+(x+y));
		System.out.println("The Character is:" + l);
		System.out.println("My name is :" +str);*/
	
		 //Demo1 obj=new Demo1();
		 //bj.callingMethod();
		 
		 //DemoReturns dr=new DemoReturns();
		// dr.ArrayDemo();
		
		//Demo2 obj = new Demo2();
		//obj.printtable();
	    //obj.generateValue();
		
		//ExceptionDemo obj =new ExceptionDemo();
		//obj.divide();
		ConstructorDemo obj=new ConstructorDemo();
		obj.add();
		
		//ConstructorDemo obj1=new ConstructorDemo(20,50);
		//obj1.add();
	}
}
