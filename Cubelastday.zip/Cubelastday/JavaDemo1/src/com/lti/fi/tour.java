package com.lti.fi;

public class tour {
	int tourid;
	string place;
	double cost;

	

}
