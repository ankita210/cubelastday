package com.lti.fi;
import java.util.Random;
import java.util.Scanner;
public class Demo2 {
	public void printtable()
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a number:");
	int x=sc.nextInt();
	
	for(int i=1;i<=10;i++)
	{
		System.out.println(x+"*"+i+"="+x*i);
	}

	}
	public void generateValue()

	{
		Random abc=new Random();
		int z=abc.nextInt();
		if(z<10)
		{
			System.out.println("Blue");
			
		}
		else
		{
			System.out.println("Red");
		}
	}
}
