package date;

public class tour {
	private int tourid;
	private String place;
	private double cost;
	private String tourdate;
	public int getTourid() {
		return tourid;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public String getTourdate() {
		return tourdate;
	}
	public void setTourdate(String tourdate) {
		this.tourdate = tourdate;
	}
	public void setTourid(int tourid) {
		this.tourid = tourid;
	}
	public tour(int tourid, String place, double cost, String tourdate) {
		super();
		this.tourid = tourid;
		this.place = place;
		this.cost = cost;
		this.tourdate = tourdate;
	}
	public tour() {
		super();
	}
}