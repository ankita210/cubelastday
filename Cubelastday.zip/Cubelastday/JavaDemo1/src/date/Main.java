package date;

import date.tour;
public class Main {
	public static void main(String args[])
	{
		tour tour1=new tour();
		System.out.println(tour1.getTourid()+" "+tour1.getPlace());
		tour1.setTourid(121);
		tour1.setPlace("Mumbai");
		System.out.println(tour1.getTourid()+" "+tour1.getPlace());
		System.out.println(tour1);
		System.out.println(tour1.hashCode());
		System.out.println(tour1.toString());
	}
	

}
