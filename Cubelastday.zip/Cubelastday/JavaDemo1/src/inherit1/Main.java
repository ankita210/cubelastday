package inherit1;


public class Main {
	
	public static void main(String args[])
	{
		A objA=new A();
		
		System.out.println("-----------------------");
		
		C objC=new C();
		
	}


}
