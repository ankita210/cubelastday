package inherit1;

public class C extends A {
	
	public C()
	{
		System.out.println("I is the mammal");
	}

}



