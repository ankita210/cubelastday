package inherit1;

public class A {
	public A()
	{
		System.out.println("I is a human");
	}

}


