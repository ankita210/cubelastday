package com.jpaproj1.app;

import com.jpaproj1.dao.ServiceDao;
import com.jpaproj1.model.Places;

public class TestApplication {

	public static void main(String[] args) {
		
		/*Places places=new Places();
		places.setLocation("Mumbai");
		places.setPlaceid(102);
		places.setPlacename("GateWay Of India");
		
		boolean flag=new ServiceDao().addPlace(places);
		System.out.println(flag);*/
		
		Places place=new Places();
		place.setPlaceid(101);
		Places p = new ServiceDao().getPlace(place);
		if(p==null)
			System.out.println("place not found");
		else
			System.out.println(p.getPlacename());
		
		System.exit(0);
	}
	
	

}
