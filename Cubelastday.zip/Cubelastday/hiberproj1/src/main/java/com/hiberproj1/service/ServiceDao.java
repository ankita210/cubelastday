package com.hiberproj1.service;




import com.hiberproj1.model.Employee;
import com.hiberproj1.model.SessionDao;


public class ServiceDao {

	public boolean addEmp(Employee e){
		boolean flag=false;
		try{
			Session session=new SessionDao().getSession();
			
			Transaction t = (Transaction) session.beginTransaction();
			session.save(e);
			t.commit();
			session.close();
			flag=true;
		}
		catch(Exception ee){
			System.out.println(ee);
		}
		return flag;
	}
	
	public boolean editEmp(Employee e){
		boolean flag=false;
		try{
			Session session=new SessionDao().getSession();
			
			Transaction t =  session.beginTransaction();
			session.update(e);
			t.commit();
			session.close();
			flag=true;
		}
		catch(Exception ee){
			System.out.println(ee);
		}
		return flag;
	}
	public boolean delEmp(Employee e){
		boolean result=false;
		try{
			Session session=new SessionDao().getSession();
			
			Transaction t = (Transaction) session.beginTransaction();
			session.delete(e);
			t.commit();
			session.close();
			result=true;
		}
		catch(Exception ee){
			System.out.println("error:"+ee);
		}
		return result;
	}
	public Employee getEmp(Employee emp){
	 Employee e1 = null;
	 try{
		 Session session = new SessionDao().getSession();
		 e1=(Employee) session.get(Employee.class, emp.getEno());
	 }
	 catch(Exception e)
	 {
		 System.out.println("Error:"+e);
	 }
	return e1;
	 
}}

