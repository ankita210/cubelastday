package web.Hibernate_Project1.model;

public @interface Entity {

}
