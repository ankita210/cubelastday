package web.Hibernate_Project1.dao;

import javax.transaction.Transaction;

import org.hibernate.Session;

import web.Hibernate_Project1.model.Employee;
import web.Hibernate_Project1.model.SessionModel;

public class ServiceDao {
	public boolean addEmp(Employee e){
		boolean flag=false;
		try{
			Session session=new SessionModel().getSession();
			
			Transaction t = (Transaction) session.beginTransaction();
			session.save(e);
			t.commit();
			session.close();
			flag=true;
		}
		catch(Exception ee){
			System.out.println(ee);
		}
		return flag;
	}

}
