package web.Hibernate_Project1.app;

import web.Hibernate_Project1.dao.ServiceDao;
import web.Hibernate_Project1.model.Employee;

public class TestApplication {

	public static void main(String[] args) {
		
		Employee employee = new Employee();
		employee.setEno(100);
		employee.setEname("RAJA");
		employee.setSalary(12908);
		System.out.println(new ServiceDao().addEmp(employee));
		System.out.println(employee.getEname());

	}

}
