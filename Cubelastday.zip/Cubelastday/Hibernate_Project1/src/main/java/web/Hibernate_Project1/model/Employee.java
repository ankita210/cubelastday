package web.Hibernate_Project1.model;


@Entity
@Table(name="employee123")


public class Employee {
	@Id
	private int eno;
	private String ename;
	@Column(name="esal")
	private int salary;
	public int getEno() {
		return eno;
	}
	public void setEno(int eno) {
		this.eno = eno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public Employee() {
		super();
	}
	
	}
	