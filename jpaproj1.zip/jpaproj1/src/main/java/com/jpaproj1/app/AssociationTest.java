package com.jpaproj1.app;

import java.util.Date;

import com.jpaproj1.dao.ServiceDao;
import com.jpaproj1.model.Booking;
import com.jpaproj1.model.Flight;

public class AssociationTest {

	public static void main(String[] args) {
		
		Flight flight =new Flight();
		flight.setFlightid("gda");
		flight.setAirline("Air asia");
		flight.setSource("mumbai");
		flight.setDestination("Meri place");
		
		Booking booking1 = new Booking();
		booking1.setBookingdate(new Date());
		booking1.setEmailid("xadb@mera.com");
		booking1.setName("ch anikta");
		booking1.setNoOfPassengers(2);
		
		
		Booking booking2 = new Booking();
		booking2.setBookingdate(new Date());
		booking2.setEmailid("xadb@tera.com");
		booking2.setName("chhhh anikta");
		booking2.setNoOfPassengers(2);
		
		flight.getBookinglist().add(booking1);
		flight.getBookinglist().add(booking2);

		boolean result = new ServiceDao().addFlight(flight);
		System.out.println(result);
		
		
	}

}
