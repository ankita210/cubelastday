package com.jpaproj1.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.jpaproj1.model.Booking;
import com.jpaproj1.model.Flight;
import com.jpaproj1.model.Places;

public class ServiceDao {
	
	/*public boolean addPlace(Places place){
		boolean result=false;
		//write code for jpa
		try{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(place);
		em.getTransaction().commit();
		result=true;
		}
		catch(Exception e) {
			System.out.println("Error:"+e);
		}
		return result;
	}
	public Places getPlace(Places place) {
		Places p=null;
		try{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		EntityManager em = emf.createEntityManager();
		p= em.find(Places.class, place.getPlaceid());
		}
		catch(Exception e) {
			System.out.println(e);
		
		}
		return p;*/
	
	public boolean addFlight(Flight flight){
		boolean result=false;
		//write code for jpa
		try{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(flight);
		em.getTransaction().commit();
		result=true;
		}
		catch(Exception e) {
			System.out.println("Error:"+e);
		}
		return result;
	}
		
		public List <Booking> getBooking(){
			List<Booking> Bookinglist=null;
			boolean result=false;
			try{
				EntityManagerFactory emf=Persistence.createEntityManagerFactory("pu");
				EntityManager em=emf.createEntityManager();
				em.getTransaction().begin();
				em.persist(Bookinglist);
				em.getTransaction().commit();
				result=true;
			}
			catch(Exception e){
				System.out.println(e);
			}
			return Bookinglist;
			
			
			
		}
}